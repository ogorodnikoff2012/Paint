------------------
The Ultimate Free Web Designer�s Icon Set (750 icons, 48x48px)
Designed by Oliver Twardowski (http://www.addictedtocoffee.de, @mywayhome on Twitter)

http://www.smashingmagazine.com/2010/04/15/the-ultimate-free-web-designer-s-icon-set-750-icons-incl-psd-sources/
------------------

Dear friends,

thank you for downloading this file.

This freebie has been brought to you by SmashingMagazine.com.
You can freely use it for both your private and commercial projects, including software, online services, templates and themes.
The icons may not be resold, sublicensed, rented, transferred or otherwise made available for use. The icons may not be offered for free downloading from websites
other than SmashingMagazine.com.
Please link to the article in which this freebie was released if you would like to spread the word.

Smashing Magazine Team,
www.smashingmagazine.com
